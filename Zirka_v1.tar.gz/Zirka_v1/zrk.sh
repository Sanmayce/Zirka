/usr/bin/time -v ./zirka "$1"
/usr/bin/time -v ./unzirka "$1"
diff "$1" "$1".restored 

