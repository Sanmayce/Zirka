// unzirka.c

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

#define CHUNK_SIZE 256

// Must match the encoder's hash function exactly
uint32_t calculate_hashsum(const uint8_t* data) {
    uint32_t hash = 0;
    for (int i = 0; i < CHUNK_SIZE; i++) {
        hash = (hash << 1) ^ data[i];
    }
    return hash;
}

int main(int argc, char* argv[]) {
    if (argc < 2) {
        printf("Usage: %s <file.deduplicatedfile>\n", argv[0]);
        return 1;
    }

    FILE* fin = fopen(argv[1], "rb");
    if (!fin) { perror("Input error"); return 1; }

    char out_name[512];
    snprintf(out_name, sizeof(out_name), "%s.restored", argv[1]);
    
    // Open for read/write (w+b) to allow back-referencing reconstructed data
    FILE* fout = fopen(out_name, "w+b");
    if (!fout) { perror("Output error"); fclose(fin); return 1; }

    int c;
    uint8_t buffer[CHUNK_SIZE];
    uint64_t current_out_pos = 0;

    printf("Decoding: %s\n", argv[1]);

    while ((c = fgetc(fin)) != EOF) {
        if (c == 255) {
            uint64_t source_offset;
            uint32_t expected_hash;
            
            // Record where the pointer data starts in the input file
            long pointer_start = ftell(fin);

            // Try to read the 8-byte offset and 4-byte hash
            if (fread(&source_offset, 8, 1, fin) == 1 && fread(&expected_hash, 4, 1, fin) == 1) {
                
                // SANITY CHECK 1: Offset must be historical
                if (source_offset < current_out_pos) {
                    long saved_pos = ftell(fout);
                    
                    // Go to historical data
                    fseek(fout, source_offset, SEEK_SET);
                    fread(buffer, 1, CHUNK_SIZE, fout);
                    
                    // SANITY CHECK 2: Does the data at that offset match the recorded hash?
                    if (calculate_hashsum(buffer) == expected_hash) {
                        fseek(fout, saved_pos, SEEK_SET);
                        fwrite(buffer, 1, CHUNK_SIZE, fout);
                        current_out_pos += CHUNK_SIZE;
                        continue; // Success, pointer resolved
                    }
                }
            }
            
            // If sanity checks fail, the '255' was just a literal byte.
            // Rewind input to just after the '255' and continue.
            fseek(fin, pointer_start, SEEK_SET);
            fseek(fout, 0, SEEK_END);
            fputc(255, fout);
            current_out_pos++;
        } else {
            // Literal byte
            fputc((uint8_t)c, fout);
            current_out_pos++;
        }

        if (current_out_pos % 1048576 == 0) {
            fprintf(stderr, "\rRestored: %lu MB", current_out_pos / 1048576);
        }
    }

    printf("\nDone. Final Size: %lu bytes\n", current_out_pos);
    fclose(fin);
    fclose(fout);
    return 0;
}

