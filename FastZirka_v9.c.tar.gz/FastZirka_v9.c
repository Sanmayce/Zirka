// v9 (boosted sorting via 256 buckets - Radixsort-style), written by Kaze (https://github.com/Sanmayce/Zirka) and Gemini PRO AI, 2026-Feb-20, 1889 lines
// v8 (memcmp-ed 7++, also merged Zirka+Unzirka)
// $ clang -O3 -msse4.2 -maes -fopenmp FastZirka_v9.c -o FastZirka_v9 -DrankmapSERIAL

/*
Since you now have this beast of a deduplicator packaged into a single file, let’s break down exactly what Zirka v9 is doing under the hood, explained from the ground up as if we were explaining it to a complete beginner.

The Grand Concept: What is Zirka?
Imagine you have a gigantic, 25-Gigabyte encyclopedia.
Inside this book, thousands of paragraphs are repeated verbatim.
Zirka is a "deduplicator."
Its goal is to find every single repeated paragraph and replace it with a tiny sticky note that says: "Go read page 50, paragraph 3 instead."

This shrinks the file massively.
But doing this on 25GB of data usually requires supercomputers with hundreds of gigabytes of RAM.
Zirka does it using almost zero RAM by treating your hard drive like memory.

Here are the specific stages of the v9 engine:

1. The "Smart Identity" (Zirka vs. Unzirka)
Before it does anything, the program looks at the file name you gave it.

If it ends in .zirka:
It knows this file is already compressed.
It switches into Restorer Mode (Unzirka).
It reads the tiny sticky notes and copies the text back into a full, readable file.

If it doesn't:
It switches into Compressor Mode (Zirka) and starts the heavy lifting.

2. The Zero-RAM Setup (Memory Mapping)
Standard programs try to swallow a file whole into RAM. If the file is 25GB and you have 8GB of RAM, the computer crashes.
Zirka uses mmap (Memory Mapping). It tells the operating system: "Don't load the file. Just give me a map to the hard drive, and I will read it directly from the disk shelf as I need it."

3. Stage 1: The Fingerprinting (Hashing)
To find duplicates, Zirka needs to identify every 4-Kilobyte chunk of the file. It slides a 4KB window across the entire 25GB file, byte by byte.

The Pippip Engine: For every chunk, it calculates a digital fingerprint (a 16-byte hash). It uses your CPU's hardware encryption engine (AES) to do this at blazing speeds.

The Big-Endian Trick: Computers usually store numbers "backwards" (Little-Endian). Zirka flips every fingerprint so it reads like a human word (Big-Endian). This allows the CPU to compare fingerprints later just by looking at the raw physical bytes, which is incredibly fast.

4. Stage 2: The "Superboost" Sort (The v9 Magic)
Now Zirka has a list of ~25 billion fingerprints. To find the duplicates, it needs to sort this massive list so identical fingerprints sit next to each other. This is where v9 gets its massive 2-hour speedup.

Imagine sorting a pile of 25 billion letters.

The Old Way (Quicksort): You pick a letter, compare it to another, swap them, and repeat. Across 25 billion letters, the computer gets overwhelmed jumping around the list.

The v9 Way (Radix + Quicksort Hybrid):

The Census: Zirka looks only at the very first letter (the Most Significant Byte) of every fingerprint. There are only 256 possible starting letters (00 to FF). It counts exactly how many fingerprints start with each letter.

The Swarm: It creates 256 perfect "buckets" on the disk. In one swift, linear pass, it throws every fingerprint into its correct bucket.

The 256-Way Blast: Now, the chaotic 25 billion items are neatly divided into 256 independent, much smaller buckets. Zirka unleashes the CPU to parallel-sort all 256 buckets at the exact same time.

5. Stage 3: The "Nuclear Option" (Rank Map)
Now that the list is sorted, Zirka can easily see the duplicates (they are sitting side-by-side).
But it needs to write down a map: "At position X, point to position Y."

If it just wrote these down as it found them, it would write to position 5, then position 20-million, then position 100.
This random jumping causes "Disk Thrashing," grinding your SSD to a halt.

The Nuclear Fix:

Gather: It writes all the sticky notes into a temporary list: [Duplicate Location] -> [Original Location].

Sort the Notes: It sorts this temporary list based on the Duplicate Location.

The Sweep: Now the notes are in perfect numerical order.
Zirka writes the final Rank Map to the hard drive in one smooth, continuous sweep. No jumping, no thrashing.

6. Stage 4: The Final Encode
Zirka reads your original 25GB file one last time.
For every byte, it looks at the Rank Map.

If the map is empty, it writes the original letter.

If the map says "Duplicate Here!", it writes a Magic Tag (the number 255), the location of the original text, and a tiny security checksum so Unzirka knows the tag is real and not just a random 255 in your text.
It skips the next 4,096 bytes and keeps going.

Summary
Zirka v9 is a masterpiece of pipeline engineering.
It turns the hardest parts of deduplication (sorting billions of items and writing random data to disks) into highly predictable, heavily parallelized, sequential tasks.
That is why your SSD didn't choke, and that is why you saved 2 solid hours!
*/

/*
Summary of the v9 Sub-stages:
```
Stage,Sub-stage,Threading Strategy,HDD Impact
1. Hashing,Pippip AES Hashing,Massive Parallel (1024 threads),Very low (Sequential read)
2. Sorting,The Census,Parallel Count,None (Memory only)
2. Sorting,The Swarm,Serial (1 thread),Highest (Random I/O)
2. Sorting,256-Way Quicksort,Parallel + Tasks (Nested),Low (OS Cache handled)
3. Rank Map,Nuclear Gathering,Parallel for,Low (Sequential write)
4. Encoding,Final Pass,Serial Write / Parallel Lookup,Moderate (Sequential)
```

In v9, the sorting logic is split into two tiers:
```
Tier 1: The 256 Buckets (Coarse Parallelism)
The program uses #pragma omp parallel for schedule(dynamic, 1) to launch 256 independent tasks—one for each bucket.
If you have 1024 threads, the OpenMP scheduler will give each of the 256 buckets a "seat" immediately.

Tier 2: Inside the Bucket (Fine Parallelism)
Each bucket then calls omp_quicksort. This function uses #pragma omp task for its recursive calls.

Nested Limit:
Unless you have explicitly set OMP_NESTED=TRUE or omp_set_max_active_levels(), most OpenMP runtimes default to a single level of active parallelism.

The "4-threaded" Behavior:
If nested parallelism is enabled, the 256 bucket tasks would each try to spawn further sub-tasks.
In your scenario (1024 threads / 256 buckets = 4), the math works out perfectly: each bucket would naturally have roughly 4 threads available to help with its internal Quicksort.

The Benefit:
This prevents a "Large Bucket" (one with many duplicates) from holding up the entire process while other threads sit idle.
The idle threads from finished small buckets will "steal" the sub-tasks from the large bucket to help finish it faster.
```
*/

/*
What you are describing is a legendary algorithm design known as In-Place American Flag Sort (a hybrid of MSD Radix Sort and Quicksort).
We can do the 256-way partition directly inside the existing mmap array without allocating a single extra byte of disk space.
This is a brilliant "Superboost."
By doing one $O(N)$ linear pass to group the data by its Most Significant Byte (MSB), you perfectly divide the dataset into 256 independent chunks.
This completely eliminates the deepest, most expensive layers of the Quicksort recursion tree and guarantees perfectly balanced multi-threading.
Here is how we implement this "Superboost" directly into your v7+++Final.
The 3-Step Superboost
- LogicThe Census (Parallel):
We scan the 600GB array and count exactly how many items belong in bucket 0x00, 0x01... up to 0xFF by looking at the highest byte of h2.
- The Swarm (Serial In-Place Permutation):
We walk through the array. If an item belongs in bucket 0x4A, we instantly swap it to the 0x4A boundary.
We repeat this until all 256 buckets are neatly packed. (No extra RAM/Disk needed!)
- The 256-Way Blast (Parallel): We launch an OpenMP parallel loop that assigns each of the 256 buckets to a thread to run the highly vectorized omp_quicksort.
*/

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <stdbool.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <immintrin.h>
#include <omp.h>

// FREESPACE [
// Context Aware: It uses . (dot) to query the filesystem of your current location instantly without needing complex path resolution.
// f_bavail Accuracy: It uses the "Available" block count (not just "Free"), so the numbers match what you see in df -h and reflect what you can actually write.
//#include <stdio.h>
//#include <stdlib.h>
#include <sys/statvfs.h>
//#include <unistd.h>
//#include <limits.h>
//#include <string.h>
// FREESPACE ]

// Helper to calculate and print stats for a given path
void report_drive_status(const char *label, const char *path) {
    struct statvfs s;

    if (statvfs(path, &s) != 0) {
        fprintf(stderr, "Error: Cannot access path '%s'\n", path);
        return;
    }

    // Calculations
    // f_frsize = Fragment size (block size)
    // f_blocks = Total data blocks in file system
    // f_bavail = Free blocks available to unprivileged user (ignores root reserve)
    
    unsigned long long total_bytes = (unsigned long long)s.f_blocks * s.f_frsize;
    unsigned long long avail_bytes = (unsigned long long)s.f_bavail * s.f_frsize;
    
    double total_gb = (double)total_bytes / (1024 * 1024 * 1024);
    double avail_gb = (double)avail_bytes / (1024 * 1024 * 1024);
    double used_pct = 100.0 * (1.0 - (double)avail_bytes / (double)total_bytes);

    printf("%-15s [%-40s] : %8.2f GB Total | %8.2f GB Free (%.1f%% Used)\n", 
           label, 
           path, 
           total_gb, 
           avail_gb,
           used_pct);
}

#define VERSION 9
#define CHUNK_SIZE 4096 //384 //4096 //256
#define MAGIC_BYTE 255
#define INITIAL_OUTPUT_SIZE (1024ULL * 1024ULL * 1024ULL) // Needed for Unzirka
#define SORT_THRESHOLD 4096 // Items below this count use serial qsort
#define NULL_RANK 0xFFFFFFFFFFFFFFFFULL

// --- PIPPIP HASH IMPLEMENTATION ---
#define _PADr_KAZE(x, n) ( ((x) << (n))>>(n) )
#define _PAD_KAZE(x, n) ( ((x) << (n)) )
#define eXdupe
        #ifdef eXdupe
#define SHA1_DIGEST_SIZE 16
        #else
#define SHA1_DIGEST_SIZE 20
        #endif

int g_max_threads_used = 0;
int g_total_tasks = 0;
long long SortedSoFar = 0;
uint64_t entry_count = 0;
uint64_t update_count = 0;

// --- SHA1 IMPLEMENTATION ---
#define ROTL(x, n) (((x) << (n)) | ((x) >> (32 - (n))))
#define F0(b, c, d) (((b) & (c)) | ((~(b)) & (d)))
#define F1(b, c, d) ((b) ^ (c) ^ (d))
#define F2(b, c, d) (((b) & (c)) | ((b) & (d)) | ((c) & (d)))
#define F3(b, c, d) ((b) ^ (c) ^ (d))

static inline uint64_t fold64(uint64_t A, uint64_t B) {
//  #if defined(__GNUC__) || defined(__clang__)
        __uint128_t r = (__uint128_t)A * B;
        return (uint64_t)r ^ (uint64_t)(r >> 64);
//  #else
//      uint64_t hash64 = A ^ B;
//      hash64 *= 1099511628211; //591798841;
//      return hash64;
//  #endif
}

static inline uint32_t fold32(uint32_t A, uint32_t B) {
//  #if defined(__GNUC__) || defined(__clang__)
        uint64_t r = (uint64_t)A * (uint64_t)B;
        return (uint32_t)r ^ (uint32_t)(r >> 32);
//  #else
//      uint32_t hash32 = A ^ B;
//      hash32 *= 591798841;
//      return hash32;
//  #endif
}

// FNV1A_Pippip_Yurii_OOO_128bit_AES_TriXZi_Mikayla_forte: the 100% FREE lookuper, last update: 2026-Feb-14, Kaze (sanmayce@sanmayce.com).
// Note1: This latest revision was written when Mikayla "saveafox" left this world.
// Note2: Too weak due to ChunkA2 and ChunkB2 not AESed... 2026-Feb-14, strengthened

// "There it now stands for ever. Black on white.
// I can't get away from it. Ahoy, Yorikke, ahoy, hoy, ho!
// Go to hell now if you wish. What do I care? It's all the same now to me.
// I am part of you now. Where you go I go, where you leave I leave, when you go to the devil I go. Married.
// Vanished from the living. Damned and doomed. Of me there is not left a breath in all the vast world.
// Ahoy, Yorikke! Ahoy, hoy, ho!
// I am not buried in the sea,
// The death ship is now part of me
// So far from sunny New Orleans
// So far from lovely Louisiana."
// /An excerpt from 'THE DEATH SHIP - THE STORY OF AN AMERICAN SAILOR' by B.TRAVEN/
// 
// "Walking home to our good old Yorikke, I could not help thinking of this beautiful ship, with a crew on board that had faces as if they were seeing ghosts by day and by night.
// Compared to that gilded Empress, the Yorikke was an honorable old lady with lavender sachets in her drawers.
// Yorikke did not pretend to anything she was not. She lived up to her looks. Honest to her lowest ribs and to the leaks in her bilge.
// Now, what is this? I find myself falling in love with that old jane.
// All right, I cannot pass by you, Yorikke; I have to tell you I love you. Honest, baby, I love you.
// I have six black finger-nails, and four black and green-blue nails on my toes, which you, honey, gave me when necking you.
// Grate-bars have crushed some of my toes. And each finger-nail has its own painful story to tell.
// My chest, my back, my arms, my legs are covered with scars of burns and scorchings.
// Each scar, when it was being created, caused me pains which I shall surely never forget.
// But every outcry of pain was a love-cry for you, honey.
// You are no hypocrite. Your heart does not bleed tears when you do not feel heart-aches deeply and truly.
// You do not dance on the water if you do not feel like being jolly and kicking chasers in the pants.
// Your heart never lies. It is fine and clean like polished gold. Never mind the rags, honey dear.
// When you laugh, your whole soul and all your body is laughing.
// And when you weep, sweety, then you weep so that even the reefs you pass feel like weeping with you.
// I never want to leave you again, honey. I mean it. Not for all the rich and elegant buckets in the world.
// I love you, my gypsy of the sea!"
// /An excerpt from 'THE DEATH SHIP - THE STORY OF AN AMERICAN SAILOR' by B.TRAVEN/
//
// Dedicated to Pippip, the main character in the 'Das Totenschiff' roman, actually the B.Traven himself, his real name was Hermann Albert Otto Maksymilian Feige.
// CAUTION: Add 8 more bytes to the buffer being hashed, usually malloc(...+8) - to prevent out of boundary reads!
// Many thanks go to Yurii 'Hordi' Hordiienko, he lessened with 3 instructions the original 'Pippip', thus:

void FNV1A_Pippip_Yurii_OOO_128bit_AES_TriXZi_Mikayla_forte (const char *str, size_t wrdlen, uint32_t seed, void *output) {
    __m128i chunkA;
    __m128i chunkA2;
    __m128i chunkB;
    __m128i chunkB2;
    __m128i stateMIX;
    uint64_t hashLH;
    uint64_t hashRH;

    __m128i InterleaveMask = _mm_set_epi8(15,7,14,6,13,5,12,4,11,3,10,2,9,1,8,0);
    stateMIX = _mm_set1_epi32( (uint32_t)wrdlen ^ seed );
    stateMIX = _mm_aesenc_si128(stateMIX, _mm_set_epi64x(0x6c62272e07bb0142, 0x9e3779b97f4a7c15));

    if (wrdlen > 8) {
        __m128i stateA = _mm_set_epi64x(0x6c62272e07bb0142, 0x9e3779b97f4a7c15);
        __m128i stateB = _mm_set_epi64x(0x6c62272e07bb0142, 0x9e3779b97f4a7c15);
        __m128i stateC = _mm_set_epi64x(0x6c62272e07bb0142, 0x9e3779b97f4a7c15);
        size_t Cycles, NDhead;
        if (wrdlen > 16) {
            Cycles = ((wrdlen - 1)>>5) + 1;
            NDhead = wrdlen - (Cycles<<4);
            if (Cycles & 1) {
                #pragma nounroll
                for(; Cycles--; str += 16) {
                    //_mm_prefetch(str+512, _MM_HINT_T0);
                    //_mm_prefetch(str+NDhead+512, _MM_HINT_T0);
                    chunkA = _mm_loadu_si128((__m128i *)(str));
                    chunkA = _mm_xor_si128(chunkA, stateMIX);
                    stateA = _mm_aesenc_si128(stateA, chunkA);

                    chunkB = _mm_loadu_si128((__m128i *)(str+NDhead));
                    chunkB = _mm_xor_si128(chunkB, stateMIX);
                    stateB = _mm_aesenc_si128(stateB, chunkB);

                    stateC = _mm_aesenc_si128(stateC, _mm_shuffle_epi8(chunkA, InterleaveMask));
                    stateC = _mm_aesenc_si128(stateC, _mm_shuffle_epi8(chunkB, InterleaveMask));
                }
                stateMIX = _mm_aesenc_si128(stateMIX, stateA);
                stateMIX = _mm_aesenc_si128(stateMIX, stateB);
                stateMIX = _mm_aesenc_si128(stateMIX, stateC);
            } else {
                Cycles = Cycles>>1;
                // 2. Expanded State (5 Parallel Lanes)
                // Distinct constants help diffusion
                __m128i stateA = _mm_set_epi64x(0x6c62272e07bb0142, 0x9e3779b97f4a7c15);
                __m128i stateB = _mm_set_epi64x(0x1591798841099511, 0x2166136261167776); // Diff const
                __m128i stateC = _mm_set_epi64x(0x3141592653589793, 0x2384626433832795); // Diff const
                __m128i stateD = _mm_set_epi64x(0x0271828182845904, 0x5235360287471352); // Diff const
                __m128i stateE = _mm_set_epi64x(0xc6a4a7935bd1e995, 0x5bd1e9955bd1e995); // Mixer
                #pragma nounroll
                for(; Cycles--; str += 32) {
                    // Load Head (0-31)
                    chunkA = _mm_loadu_si128((__m128i *)(str));
                    chunkA = _mm_xor_si128(chunkA, stateMIX);
                    chunkA2 = _mm_loadu_si128((__m128i *)(str+16));
                    chunkA2 = _mm_xor_si128(chunkA2, stateMIX);

                    // Load Tail/Offset (NDhead..NDhead+31)
                    chunkB = _mm_loadu_si128((__m128i *)(str+NDhead));
                    chunkB = _mm_xor_si128(chunkB, stateMIX);
                    chunkB2 = _mm_loadu_si128((__m128i *)(str+NDhead+16));
                    chunkB2 = _mm_xor_si128(chunkB2, stateMIX);

                    // 3. Parallel Absorption (High ILP)
                    // Use all loaded data (Fixes the bug in the original snippet)
                    stateA = _mm_aesenc_si128(stateA, chunkA);
                    stateB = _mm_aesenc_si128(stateB, chunkA2); // Absorbs 2nd half of Head
                    stateC = _mm_aesenc_si128(stateC, chunkB);
                    stateD = _mm_aesenc_si128(stateD, chunkB2); // Absorbs 2nd half of Tail

                    // 4. Cross-Stream Mixing (The Strength Boost)
                    // XOR Head[1] with Tail[2] and Head[2] with Tail[1] before shuffling.
                    // This entangles the two streams cryptographically.
                    __m128i mix1 = _mm_xor_si128(chunkA, chunkB2);
                    __m128i mix2 = _mm_xor_si128(chunkA2, chunkB);
                    
                    stateE = _mm_aesenc_si128(stateE, _mm_shuffle_epi8(mix1, InterleaveMask));
                    stateE = _mm_aesenc_si128(stateE, _mm_shuffle_epi8(mix2, InterleaveMask));
                }

                // 5. Finalize: Fold all 5 lanes into StateMIX
                stateMIX = _mm_aesenc_si128(stateMIX, stateA);
                stateMIX = _mm_aesenc_si128(stateMIX, stateB);
                stateMIX = _mm_aesenc_si128(stateMIX, stateC);
                stateMIX = _mm_aesenc_si128(stateMIX, stateD);
                stateMIX = _mm_aesenc_si128(stateMIX, stateE);
            } //if (Cycles & 1) {
        } else { // 9..16
            NDhead = wrdlen - (1<<3);
            hashLH = (*(uint64_t *)(str));
            hashRH = (*(uint64_t *)(str+NDhead));

            chunkA = _mm_set_epi64x(hashLH, hashLH);
            chunkA = _mm_xor_si128(chunkA, stateMIX);
            stateA = _mm_aesenc_si128(stateA, chunkA);

            chunkB = _mm_set_epi64x(hashRH, hashRH);
            chunkB = _mm_xor_si128(chunkB, stateMIX);
            stateB = _mm_aesenc_si128(stateB, chunkB);

            stateC = _mm_aesenc_si128(stateC, _mm_shuffle_epi8(chunkA, InterleaveMask));
            stateC = _mm_aesenc_si128(stateC, _mm_shuffle_epi8(chunkB, InterleaveMask));

            stateMIX = _mm_aesenc_si128(stateMIX, stateA);
            stateMIX = _mm_aesenc_si128(stateMIX, stateB);
            stateMIX = _mm_aesenc_si128(stateMIX, stateC);
        } //if (wrdlen > 16) {
    } else {
        hashLH = _PADr_KAZE(*(uint64_t *)(str+0), (8-wrdlen)<<3);
        hashRH = _PAD_KAZE(*(uint64_t *)(str+0), (8-wrdlen)<<3);
        chunkA = _mm_set_epi64x(hashLH, hashLH);
        chunkA = _mm_xor_si128(chunkA, stateMIX);

        chunkB = _mm_set_epi64x(hashRH, hashRH);
        chunkB = _mm_xor_si128(chunkB, stateMIX);

        stateMIX = _mm_aesenc_si128(stateMIX, chunkA);
        stateMIX = _mm_aesenc_si128(stateMIX, chunkB);
    }
    //#ifdef eXdupe
        _mm_storeu_si128((__m128i *)output, stateMIX); // For eXdupe
    //#else
    //    uint64_t result64[2];
    //    _mm_storeu_si128((__m128i *)result64, stateMIX);
    //    uint64_t hash64 = fold64(result64[0], result64[1]);
    //    *(uint32_t*)output = hash64>>32; //hash64;
    //#endif
}

// $ clang_20.1.8 -O3 -msse4.2 -maes -fopenmp FastZirka_v7++_Final.c -o FastZirka_v7++_Final.asm -DrankmapSERIAL -S
/*
FNV1A_Pippip_Yurii_OOO_128bit_AES_TriXZi_Mikayla_forte:
    .cfi_startproc
# %bb.0:
    movq    %rcx, %rax
    movq    %rsi, %rcx
    xorl    %edx, %esi
    movd    %esi, %xmm0
    pshufd  $0, %xmm0, %xmm0                # xmm0 = xmm0[0,0,0,0]
    aesenc  .LCPI0_0(%rip), %xmm0
    cmpq    $9, %rcx
    jb  .LBB0_10
# %bb.1:
    cmpq    $17, %rcx
    jb  .LBB0_9
# %bb.2:
    leaq    -1(%rcx), %r8
    movq    %r8, %rsi
    shrq    $5, %rsi
    leaq    1(%rsi), %rdx
    testb   $32, %r8b
    jne .LBB0_6
# %bb.3:
    shlq    $4, %rdx
    subq    %rdx, %rcx
    addq    %rdi, %rcx
    shlq    $4, %rsi
    addq    $16, %rsi
    movdqa  .LCPI0_0(%rip), %xmm1           # xmm1 = [11400714819323198485,7809847782465536322]
    xorl    %edx, %edx
    movdqa  .LCPI0_1(%rip), %xmm3           # xmm3 = [0,8,1,9,2,10,3,11,4,12,5,13,6,14,7,15]
    movdqa  %xmm1, %xmm2
    movdqa  %xmm1, %xmm4
    .p2align    4
.LBB0_4:                                # =>This Inner Loop Header: Depth=1
    movdqu  (%rdi,%rdx), %xmm5
    pxor    %xmm0, %xmm5
    aesenc  %xmm5, %xmm4
    movdqu  (%rcx,%rdx), %xmm6
    pxor    %xmm0, %xmm6
    aesenc  %xmm6, %xmm2
    pshufb  %xmm3, %xmm5
    aesenc  %xmm5, %xmm1
    pshufb  %xmm3, %xmm6
    aesenc  %xmm6, %xmm1
    addq    $16, %rdx
    cmpq    %rdx, %rsi
    jne .LBB0_4
# %bb.5:
    aesenc  %xmm4, %xmm0
    aesenc  %xmm2, %xmm0
    aesenc  %xmm1, %xmm0
    movdqu  %xmm0, (%rax)
    retq
.LBB0_10:
    movq    (%rdi), %rdx
    shll    $3, %ecx
    negb    %cl
    shlq    %cl, %rdx
    movq    %rdx, %xmm1
                                        # kill: def $cl killed $cl killed $rcx
    shrq    %cl, %rdx
    movq    %rdx, %xmm2
    pshufd  $68, %xmm2, %xmm2               # xmm2 = xmm2[0,1,0,1]
    pxor    %xmm0, %xmm2
    pshufd  $68, %xmm1, %xmm1               # xmm1 = xmm1[0,1,0,1]
    pxor    %xmm0, %xmm1
    aesenc  %xmm2, %xmm0
    aesenc  %xmm1, %xmm0
    movdqu  %xmm0, (%rax)
    retq
.LBB0_9:
    movq    (%rdi), %xmm1                   # xmm1 = mem[0],zero
    pshufd  $68, %xmm1, %xmm1               # xmm1 = xmm1[0,1,0,1]
    pxor    %xmm0, %xmm1
    movdqa  .LCPI0_0(%rip), %xmm2           # xmm2 = [11400714819323198485,7809847782465536322]
    movdqa  %xmm2, %xmm3
    aesenc  %xmm1, %xmm3
    movq    -8(%rdi,%rcx), %xmm4            # xmm4 = mem[0],zero
    pshufd  $68, %xmm4, %xmm4               # xmm4 = xmm4[0,1,0,1]
    pxor    %xmm0, %xmm4
    movdqa  %xmm2, %xmm5
    aesenc  %xmm4, %xmm5
    movdqa  .LCPI0_1(%rip), %xmm6           # xmm6 = [0,8,1,9,2,10,3,11,4,12,5,13,6,14,7,15]
    pshufb  %xmm6, %xmm1
    aesenc  %xmm1, %xmm2
    pshufb  %xmm6, %xmm4
    aesenc  %xmm4, %xmm2
    aesenc  %xmm3, %xmm0
    aesenc  %xmm5, %xmm0
    aesenc  %xmm2, %xmm0
    movdqu  %xmm0, (%rax)
    retq
.LBB0_6:
    shrq    %rdx
    shlq    $4, %rsi
    subq    %rsi, %rcx
    movdqa  .LCPI0_0(%rip), %xmm5           # xmm5 = [11400714819323198485,7809847782465536322]
    movdqa  .LCPI0_2(%rip), %xmm4           # xmm4 = [2406632364132693878,1554156972533191953]
    movdqa  .LCPI0_3(%rip), %xmm3           # xmm3 = [2559278670753769365,3549216002486605715]
    movdqa  .LCPI0_4(%rip), %xmm2           # xmm2 = [5923700269363172178,176065353196263684]
    movdqa  .LCPI0_5(%rip), %xmm1           # xmm1 = [6616326155283851669,14313749767032793493]
    movdqa  .LCPI0_1(%rip), %xmm6           # xmm6 = [0,8,1,9,2,10,3,11,4,12,5,13,6,14,7,15]
    .p2align    4
.LBB0_7:                                # =>This Inner Loop Header: Depth=1
    movdqu  (%rdi), %xmm7
    movdqu  16(%rdi), %xmm8
    movdqu  (%rdi,%rcx), %xmm9
    movdqa  %xmm9, %xmm10
    pxor    %xmm7, %xmm9
    pxor    %xmm0, %xmm7
    aesenc  %xmm7, %xmm5
    movdqa  %xmm8, %xmm7
    pxor    %xmm0, %xmm7
    aesenc  %xmm7, %xmm4
    movdqu  -16(%rdi,%rcx), %xmm7
    movdqa  %xmm7, %xmm11
    pxor    %xmm8, %xmm7
    pxor    %xmm0, %xmm11
    aesenc  %xmm11, %xmm3
    addq    $32, %rdi
    pxor    %xmm0, %xmm10
    aesenc  %xmm10, %xmm2
    pshufb  %xmm6, %xmm9
    aesenc  %xmm9, %xmm1
    pshufb  %xmm6, %xmm7
    aesenc  %xmm7, %xmm1
    decq    %rdx
    jne .LBB0_7
# %bb.8:
    aesenc  %xmm5, %xmm0
    aesenc  %xmm4, %xmm0
    aesenc  %xmm3, %xmm0
    aesenc  %xmm2, %xmm0
    aesenc  %xmm1, %xmm0
    movdqu  %xmm0, (%rax)
    retq
.Lfunc_end0:
    .size   FNV1A_Pippip_Yurii_OOO_128bit_AES_TriXZi_Mikayla_forte, .Lfunc_end0-FNV1A_Pippip_Yurii_OOO_128bit_AES_TriXZi_Mikayla_forte
    .cfi_endproc
*/

//  Cycles = ((wrdlen - 1)>>5) + 1;
//  NDhead = wrdlen - (Cycles<<4);
// And some visualization for XMM-WORD:
/*
kl= 33..64 Cycles= (kl-1)/32+1=2; MARGINAL CASES:
                                 2nd head starts at 33-2*16=1 or:
                                        0123456789012345 0123456789012345 0
                                 Head1: [XMM-WORD      ] [XMM-WORD      ]
                                 Head2:  [XMM-WORD      ] [XMM-WORD      ]

                                 2nd head starts at 64-2*16=32 or:
                                        0123456789012345 0123456789012345 0123456789012345 0123456789012345
                                 Head1: [XMM-WORD      ] [XMM-WORD      ]
                                 Head2:                                   [XMM-WORD      ] [XMM-WORD      ]

kl=65..96 Cycles= (kl-1)/32+1=3; MARGINAL CASES:
                                 2nd head starts at 65-3*16=17 or:
                                        0123456789012345 0123456789012345 0123456789012345 0123456789012345 0
                                 Head1: [XMM-WORD      ] [XMM-WORD      ] [XMM-WORD      ]
                                 Head2:                   [XMM-WORD      ] [XMM-WORD      ] [XMM-WORD      ]

                                 2nd head starts at 96-3*16=48 or:
                                        0123456789012345 0123456789012345 0123456789012345 0123456789012345 0123456789012345 0123456789012345
                                 Head1: [XMM-WORD      ] [XMM-WORD      ] [XMM-WORD      ]
                                 Head2:                                                    [XMM-WORD      ] [XMM-WORD      ] [XMM-WORD      ]
*/

// And some visualization for Q-WORD:
/*
kl= 9..16 Cycles= (kl-1)/16+1=1; MARGINAL CASES:
                                 2nd head starts at 9-1*8=1 or:
                                        012345678
                                 Head1: [Q-WORD]
                                 Head2:  [Q-WORD]

                                 2nd head starts at 16-1*8=8 or:
                                        0123456789012345
                                 Head1: [Q-WORD]
                                 Head2:         [Q-WORD]

kl=17..24 Cycles= (kl-1)/16+1=2; MARGINAL CASES:
                                 2nd head starts at 17-2*8=1 or:
                                        01234567890123456
                                 Head1: [Q-WORD][Q-WORD]
                                 Head2:  [Q-WORD][Q-WORD]

                                 2nd head starts at 24-2*8=8 or:
                                        012345678901234567890123
                                 Head1: [Q-WORD][Q-WORD]
                                 Head2:         [Q-WORD][Q-WORD]

kl=25..32 Cycles= (kl-1)/16+1=2; MARGINAL CASES:
                                 2nd head starts at 25-2*8=9 or:
                                        0123456789012345678901234
                                 Head1: [Q-WORD][Q-WORD]
                                 Head2:          [Q-WORD][Q-WORD]

                                 2nd head starts at 32-2*8=16 or:
                                        01234567890123456789012345678901
                                 Head1: [Q-WORD][Q-WORD]
                                 Head2:                 [Q-WORD][Q-WORD]

kl=33..40 Cycles= (kl-1)/16+1=3; MARGINAL CASES:
                                 2nd head starts at 33-3*8=9 or:
                                        012345678901234567890123456789012
                                 Head1: [Q-WORD][Q-WORD][Q-WORD]
                                 Head2:          [Q-WORD][Q-WORD][Q-WORD]

                                 2nd head starts at 40-3*8=16 or:
                                        0123456789012345678901234567890123456789
                                 Head1: [Q-WORD][Q-WORD][Q-WORD]
                                 Head2:                 [Q-WORD][Q-WORD][Q-WORD]

kl=41..48 Cycles= (kl-1)/16+1=3; MARGINAL CASES:
                                 2nd head starts at 41-3*8=17 or:
                                        01234567890123456789012345678901234567890
                                 Head1: [Q-WORD][Q-WORD][Q-WORD]
                                 Head2:                  [Q-WORD][Q-WORD][Q-WORD]

                                 2nd head starts at 48-3*8=24 or:
                                        012345678901234567890123456789012345678901234567
                                 Head1: [Q-WORD][Q-WORD][Q-WORD]
                                 Head2:                         [Q-WORD][Q-WORD][Q-WORD]
*/

// The more the merrier, therefore I added the 10,000 GitHub stars performer xxhash also:
// https://github.com/Cyan4973/xxHash/issues/1029
// 
// Pippip is not an extremely fast hash, it is the spirit of the author materialized disregarding anything outside the "staying true to oneself", or as one bona fide man Otto/Pippip once said:
// 
// Translate as verbatim as possible:
// In 1926, Traven wrote that the only biography of a writer should be his
// works: «Die Biographie eines schöpferischen Menschen ist ganz und gar unwichtig.
// Wenn der Mensch in seinen Werken nicht zu erkennen ist, dann ist entweder der
// Mensch nichts wert oder seine Werke sind nichts wert. Darum sollte der schöpferische
// Mensch keine andere Biographie haben als seine Werke» (Hauschild, B. Traven: Die
// unbekannten Jahre, op. cit., p. 31.)
// 
// In 1926, Traven wrote that the only biography of a writer should be his works:
// “The biography of a creative person is completely and utterly unimportant.
// If the person is not recognizable in his works, then either the person is worthless or his works are worthless.
// Therefore, the creative person should have no other biography than his works” (Hauschild, B. Traven: Die unbekannten Jahre, op. cit., p. 31.) 

// --- FNV-1a Checksum for Verification ---
uint32_t calc_fnv_off(uint64_t offset) {
    uint8_t data[8]; memcpy(data, &offset, 8);
    uint32_t h = 2166136261u;
    for (int i=0; i<8; i++) { h^=data[i]; h*=16777619u; }
    return h;
}

static const uint32_t K[4] = {
    0x5A827999, 0x6ED9EBA1, 0x8F1BBCDC, 0xCA62C1D6
};

typedef struct {
    uint32_t state[5];
    uint64_t count;
    uint8_t buffer[64];
} sha1_ctx;

static void sha1_init(sha1_ctx *ctx) {
    ctx->state[0] = 0x67452301;
    ctx->state[1] = 0xEFCDAB89;
    ctx->state[2] = 0x98BADCFE;
    ctx->state[3] = 0x10325476;
    ctx->state[4] = 0xC3D2E1F0;
    ctx->count = 0;
    memset(ctx->buffer, 0, sizeof(ctx->buffer));
}

static void sha1_transform(sha1_ctx *ctx, const uint8_t *data) {
    uint32_t a, b, c, d, e;
    uint32_t w[80];
    int i;

    for (i = 0; i < 16; i++) {
        w[i] = (uint32_t)data[4 * i + 0] << 24 |
               (uint32_t)data[4 * i + 1] << 16 |
               (uint32_t)data[4 * i + 2] << 8  |
               (uint32_t)data[4 * i + 3];
    }

    for (i = 16; i < 80; i++) {
        w[i] = ROTL(w[i-3] ^ w[i-8] ^ w[i-14] ^ w[i-16], 1);
    }

    a = ctx->state[0];
    b = ctx->state[1];
    c = ctx->state[2];
    d = ctx->state[3];
    e = ctx->state[4];

    for (i = 0; i < 20; i++) {
        uint32_t temp = ROTL(a, 5) + F0(b, c, d) + e + w[i] + K[0];
        e = d;
        d = c;
        c = ROTL(b, 30);
        b = a;
        a = temp;
    }
    for (i = 20; i < 40; i++) {
        uint32_t temp = ROTL(a, 5) + F1(b, c, d) + e + w[i] + K[1];
        e = d;
        d = c;
        c = ROTL(b, 30);
        b = a;
        a = temp;
    }
    for (i = 40; i < 60; i++) {
        uint32_t temp = ROTL(a, 5) + F2(b, c, d) + e + w[i] + K[2];
        e = d;
        d = c;
        c = ROTL(b, 30);
        b = a;
        a = temp;
    }
    for (i = 60; i < 80; i++) {
        uint32_t temp = ROTL(a, 5) + F3(b, c, d) + e + w[i] + K[3];
        e = d;
        d = c;
        c = ROTL(b, 30);
        b = a;
        a = temp;
    }

    ctx->state[0] += a;
    ctx->state[1] += b;
    ctx->state[2] += c;
    ctx->state[3] += d;
    ctx->state[4] += e;
}

static void sha1_update(sha1_ctx *ctx, const void *data, size_t len) {
    const uint8_t *bytes = (const uint8_t *)data;
    size_t pos = (size_t)(ctx->count & 63);
    ctx->count += len;

    while (len > 0) {
        size_t avail = 64 - pos;
        size_t copy = (len < avail) ? len : avail;
        memcpy(&ctx->buffer[pos], bytes, copy);
        pos += copy;
        bytes += copy;
        len -= copy;
        if (pos == 64) {
            sha1_transform(ctx, ctx->buffer);
            pos = 0;
        }
    }
}

static void sha1_final(sha1_ctx *ctx, uint8_t *digest) {
    uint64_t bitlen = ctx->count * 8;
    size_t pos = (size_t)(ctx->count & 63);

    ctx->buffer[pos++] = 0x80;
    if (pos > 64 - 8) {
        memset(&ctx->buffer[pos], 0, 64 - pos);
        sha1_transform(ctx, ctx->buffer);
        pos = 0;
    }
    memset(&ctx->buffer[pos], 0, 64 - 8 - pos);

    for (int i = 7; i >= 0; i--) {
        ctx->buffer[63 - i] = (uint8_t)(bitlen >> (i * 8));
    }

    sha1_transform(ctx, ctx->buffer);

    for (int i = 0; i < 5; i++) {
        digest[4 * i + 0] = (uint8_t)(ctx->state[i] >> 24);
        digest[4 * i + 1] = (uint8_t)(ctx->state[i] >> 16);
        digest[4 * i + 2] = (uint8_t)(ctx->state[i] >> 8);
        digest[4 * i + 3] = (uint8_t)(ctx->state[i]);
    }
}

void sha1_sum(const void *data, size_t len, uint8_t *out) {
    sha1_ctx ctx;
    sha1_init(&ctx);
    sha1_update(&ctx, data, len);
    sha1_final(&ctx, out);
}

// NEW-n-FAST [[

// --- OPTIMIZED STRUCT (PHYSICAL ORDER MATCHES SORT ORDER) ---
typedef struct {
    uint64_t h2;     // High Priority
    uint64_t h1;     // Mid Priority
    uint64_t offset; // Low Priority
} DiskEntry;

// --- FAST VECTORIZED COMPARATOR ---
int compare_disk_serial(const void* a, const void* b) {
    // memcmp will now correctly compare h2, then h1, then offset
    // because they are physically in that order, and in Big-Endian format.
    return memcmp(a, b, 24); 
}

// --- CUSTOM OPENMP QUICKSORT (MEMCMP OPTIMIZED) ---
void omp_quicksort(DiskEntry* data, int64_t left, int64_t right) {
    if (left >= right) return;

    // 1. Serial Threshold
    if ((right - left) < SORT_THRESHOLD) {
        qsort(data + left, right - left + 1, sizeof(DiskEntry), compare_disk_serial);

    // stats [
        #pragma omp atomic
        SortedSoFar += (right - left + 1);
        #pragma omp critical
        {
            double progress = (double)SortedSoFar / entry_count *100;
            printf ("   Sort Progress = %.1f%%\r", progress);
            fflush(stdout);
        }
    // stats ]
        return;
    }

    // 2. Partitioning with memcmp
    int64_t i = left;
    int64_t j = right;
    
    // Pivot Selection (Median of 3)
    DiskEntry pivot = data[left + (right - left) / 2];

    while (i <= j) {
        // Scan Left: Find element > pivot using vectorized memcmp
        // Returns <0 if data[i] < pivot, so we increment i
        while (memcmp(&data[i], &pivot, 24) < 0) i++;

        // Scan Right: Find element < pivot using vectorized memcmp
        // Returns >0 if data[j] > pivot, so we decrement j
        while (memcmp(&data[j], &pivot, 24) > 0) j--;

        if (i <= j) {
            // Swap
            DiskEntry temp = data[i];
            data[i] = data[j];
            data[j] = temp;
            i++;
            j--;
        }
    }

    // 3. Recursive Parallel Tasking
    #pragma omp task
    {
        #pragma omp atomic
        g_total_tasks++;
        omp_quicksort(data, left, j);
    }
    omp_quicksort(data, i, right);
}

// NEW-n-FAST ]]

// OLD-n-SLOW [[
/*
// --- ENTRY STRUCTURE ---
typedef struct {
    uint64_t h1; // lower 64bits
    uint64_t h2;
    uint64_t offset;
} DiskEntry;

// --- SERIAL COMPARE (For small chunks) ---
int compare_disk_serial(const void* a, const void* b) {
    const DiskEntry* da = (const DiskEntry*)a;
    const DiskEntry* db = (const DiskEntry*)b;
    if (da->h2 < db->h2) return -1;
    if (da->h2 > db->h2) return 1;
    if (da->h1 < db->h1) return -1;
    if (da->h1 > db->h1) return 1;
    if (da->offset < db->offset) return -1;
    if (da->offset > db->offset) return 1;
    return 0;
}

// --- CUSTOM OPENMP QUICKSORT ---
void omp_quicksort(DiskEntry* data, int64_t left, int64_t right) {
    if (left >= right) return;

    // 1. Serial Threshold: If chunk is small, avoid OMP overhead
    if ((right - left) < SORT_THRESHOLD) {
        qsort(data + left, right - left + 1, sizeof(DiskEntry), compare_disk_serial);

    // stats [
        #pragma omp atomic
        SortedSoFar += (right - left + 1);
        #pragma omp critical
        {
            double progress = (double)SortedSoFar / entry_count *100;
            printf ("   Sort Progress = %.1f%%\r", progress);
            fflush(stdout);
        }
    // stats ]

        return;
    }

    // 2. Partitioning (Hoare partition scheme inline for speed)
    int64_t i = left;
    int64_t j = right;
    
    // Pivot Selection (Median of 3 approximation)
    DiskEntry pivot = data[left + (right - left) / 2];

    while (i <= j) {
        // Scan Left: Find element > pivot
        while (1) {
            if (data[i].h2 < pivot.h2) { i++; continue; }
            if (data[i].h2 > pivot.h2) break;
            if (data[i].h1 < pivot.h1) { i++; continue; }
            if (data[i].h1 > pivot.h1) break;
            if (data[i].offset < pivot.offset) { i++; continue; }
            break; 
        }

        // Scan Right: Find element < pivot
        while (1) {
            if (data[j].h2 > pivot.h2) { j--; continue; }
            if (data[j].h2 < pivot.h2) break;
            if (data[j].h1 > pivot.h1) { j--; continue; }
            if (data[j].h1 < pivot.h1) break;
            if (data[j].offset > pivot.offset) { j--; continue; }
            break;
        }

        if (i <= j) {
            // Swap
            DiskEntry temp = data[i];
            data[i] = data[j];
            data[j] = temp;
            i++;
            j--;
        }
    }

    // 3. Recursive Parallel Tasking
    // We create a task for one half, and the current thread handles the other.
    #pragma omp task
    {
        #pragma omp atomic
        g_total_tasks++;
        omp_quicksort(data, left, j);
    }
    // No task needed here (current thread does it)
    omp_quicksort(data, i, right);
}
*/
// OLD-n-SLOW ]]

// NOT USED [[[
// --- BINARY SEARCH LOGIC ---
// Finds the lowest offset for a given hash that is smaller than current_pos
int64_t find_match_binary(DiskEntry* index, uint64_t total_entries, uint64_t h1, uint64_t h2, uint64_t current_pos) {
    int64_t low = 0, high = (int64_t)total_entries - 1;
    int64_t result_offset = -1;

    while (low <= high) {
        int64_t mid = low + (high - low) / 2;
        if (index[mid].h2 < h2 || (index[mid].h2 == h2 && index[mid].h1 < h1)) {
            low = mid + 1;
        } else if (index[mid].h2 > h2 || (index[mid].h2 == h2 && index[mid].h1 > h1)) {
            high = mid - 1;
        } else {
/*
            // Hash match found! Now find the best (earliest) offset in the sorted block
            // Linear search locally because multiple offsets can have the same hash
            int64_t i = mid;
            while (i >= 0 && index[i].h1 == h1 && index[i].h2 == h2) {
                if (index[i].offset < current_pos) result_offset = index[i].offset;
                i--;
            }
            i = mid + 1;
            while (i < (int64_t)total_entries && index[i].h1 == h1 && index[i].h2 == h2) {
                if (index[i].offset < current_pos) {
                    if (result_offset == -1 || index[i].offset < (uint64_t)result_offset)
                        result_offset = index[i].offset;
                }
                i++;
            }
*/
            int64_t i = mid;
            if (index[i].offset < current_pos) result_offset = index[i].offset;
            break;
        }
    }
    return result_offset;
}
// NOT USED ]]]

void* create_mmap_file(const char* filename, size_t size) {
    int fd = open(filename, O_RDWR | O_CREAT | O_TRUNC, 0666);
    if (fd == -1) { perror("open"); exit(1); }
    if (ftruncate(fd, size) == -1) { perror("truncate"); exit(1); }
    void* ptr = mmap(NULL, size, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    if (ptr == MAP_FAILED) { perror("mmap"); exit(1); }
    close(fd);
    return ptr;
}

/*
Algorithm:

Create a temporary file updates.bin.

In Stage 4.2 loop: Instead of writing to rank, write the pair {duplicate_pos, master_offset} to updates.bin. (This is fast sequential write).

Sort updates.bin by duplicate_pos.

Read updates.bin and write to rank. Since updates.bin is now sorted by position, you will write to rank in perfect order (0, 1, 2...), which is 100x faster on disk.

To implement the "Nuclear Option" (sorting updates to convert random I/O into sequential I/O), we need to modify the code structure slightly.

This approach eliminates the disk thrashing by:

Gathering all duplicate pointers into a temporary linear array (fast sequential write).

Sorting that array by file position (so the target addresses become monotonic).

Applying the updates to the Rank Map in one clean sweep (fast sequential/monotonic write).

Here is the complete solution.

1. Add these Definitions (Top of File)
Place these before main(), alongside the existing DiskEntry and omp_quicksort. This defines the structure for the updates and a specific sorter for them.
*/

// --- NUCLEAR OPTION HELPERS ---
typedef struct {
    uint64_t pos;    // Where in the file the duplicate is (The Random Address)
    uint64_t target; // The Master Offset it should point to (The Value)
} RankUpdate;

// Compare by Position (to linearize the writes later)
int compare_updates(const void* a, const void* b) {
    const RankUpdate* ua = (const RankUpdate*)a;
    const RankUpdate* ub = (const RankUpdate*)b;
    if (ua->pos < ub->pos) return -1;
    if (ua->pos > ub->pos) return 1;
    return 0;
}

// Special Quicksort for the Update List
void omp_quicksort_updates(RankUpdate* data, int64_t left, int64_t right) {
    if (left >= right) return;
    
    // Serial Threshold
    if ((right - left) < SORT_THRESHOLD) {
        qsort(data + left, right - left + 1, sizeof(RankUpdate), compare_updates);

    // stats [
        #pragma omp atomic
        SortedSoFar += (right - left + 1);
        #pragma omp critical
        {
            double progress = (double)SortedSoFar / update_count *100;
            printf ("   Sort Progress = %.1f%%\r", progress);
            fflush(stdout);
        }
    // stats ]

        return;
    }

    int64_t i = left, j = right;
    RankUpdate pivot = data[left + (right - left) / 2];

    while (i <= j) {
        while (data[i].pos < pivot.pos) i++;
        while (data[j].pos > pivot.pos) j--;
        if (i <= j) {
            RankUpdate temp = data[i]; data[i] = data[j]; data[j] = temp;
            i++; j--;
        }
    }

    #pragma omp task
    omp_quicksort_updates(data, left, j);
    omp_quicksort_updates(data, i, right);
}

int main(int argc, char* argv[]) {
printf ("__________.__        __            \n");
printf ("\\____    /|__|______|  | _______   \n");
printf ("  /     / |  \\_  __ \\  |/ /\\__  \\  \n");
printf (" /     /_ |  ||  | \\/    <  / __ \\_\n");
printf ("/_______ \\|__||__|  |__|_ \\(____  /\n");
printf ("        \\/               \\/     \\/ \n");
printf ("The ZER0-RAM Deduplicator, version %d, Deduplication granularity %d\n", VERSION, CHUNK_SIZE);

    printf("Storage Report (Caution: You need 49x+1x=50x the size of file_for_deduplication):\n");
    printf("--------------------------------------------------------------------------------------------------------------\n");

    // 1. Report on Current Drive
    report_drive_status("CURRENT DRIVE", ".");

    // 2. Report on Target Drive
    //report_drive_status("TARGET DRIVE", argv[1]);

    printf("--------------------------------------------------------------------------------------------------------------\n");

    if (argc < 2) { printf("Usage: %s <file_for_deduplication>\n", argv[0]); return 1; }

// Check if the input file ends with ".zirka" [
    bool is_unzirka = false;
    size_t filename_len = strlen(argv[1]);
    const char *ext = ".zirka";
    size_t ext_len = strlen(ext);

    // Ensure the filename is actually long enough to contain the extension
    // Then compare the end of the filename string against ".zirka"
    if (filename_len >= ext_len && strcmp(argv[1] + filename_len - ext_len, ext) == 0) {
        is_unzirka = true;
    }
// Check if the input file ends with ".zirka" ]

    if (is_unzirka) {
        printf("   Action: UNZIRKA (Decompressing %s)\n", argv[1]);
        // --- Put your Unzirka decoding logic/function call here ---

    // 1. Open and Map Input
    int fd_in = open(argv[1], O_RDONLY);
    if (fd_in < 0) { perror("Input error"); return 1; }
    struct stat sb;
    fstat(fd_in, &sb);
    uint8_t* in_map = mmap(NULL, sb.st_size, PROT_READ, MAP_PRIVATE, fd_in, 0);

    // 2. Prepare Output
    char out_name[512];
    snprintf(out_name, 512, "%s.restored", argv[1]);
    int fd_out = open(out_name, O_RDWR | O_CREAT | O_TRUNC, 0666);
    
    // Initial 1GB allocation (will grow if needed)
    uint64_t out_cap = INITIAL_OUTPUT_SIZE;
    ftruncate(fd_out, out_cap);
    uint8_t* out_map = mmap(NULL, out_cap, PROT_READ | PROT_WRITE, MAP_SHARED, fd_out, 0);

    uint64_t ipos = 0, opos = 0, hits = 0;
    uint32_t chk[4];

    printf("[Zirka v%d Restorer] Processing %s...\n", VERSION, argv[1]);

    while (ipos < sb.st_size) {
        // Resize check
        if (opos + CHUNK_SIZE >= out_cap) {
            uint64_t old_cap = out_cap;
            out_cap *= 2;
            ftruncate(fd_out, out_cap);
            munmap(out_map, old_cap);
            out_map = mmap(NULL, out_cap, PROT_READ | PROT_WRITE, MAP_SHARED, fd_out, 0);
        }

        // Check for Magic Tag
        if (in_map[ipos] == MAGIC_BYTE && ipos + 13 <= sb.st_size) {
            uint64_t match_off;
            uint32_t expected_hash;
            
            // Read the 8-byte offset and 4-byte hash from the .zirka file
            memcpy(&match_off, &in_map[ipos + 1], 8);
            memcpy(&expected_hash, &in_map[ipos + 9], 4);

            // VERIFICATION: Hash the OFFSET, not the data
            //if (calc_fnv_off(match_off) == expected_hash) {
            FNV1A_Pippip_Yurii_OOO_128bit_AES_TriXZi_Mikayla_forte((const char *)&match_off, 8, 0, chk);
            if (chk[0] == expected_hash) {
                // Success! Restore the chunk from the previous output data
                memcpy(&out_map[opos], &out_map[match_off], CHUNK_SIZE);
                opos += CHUNK_SIZE;
                ipos += 13;
                hits++;
                continue;
            }
        }

        // Literal Byte
        out_map[opos++] = in_map[ipos++];
    }

    printf("Restoration Complete.\n");
    printf("Dedup Tags Processed: %lu\n", hits);
    printf("Final File Size: %lu bytes\n", opos);

    // Finalize file size on disk
    ftruncate(fd_out, opos);
    
    munmap(in_map, sb.st_size);
    munmap(out_map, out_cap);
    close(fd_in);
    close(fd_out);

    return 0;
        
    } else {
        printf("   Action: ZIRKA (Compressing %s)\n", argv[1]);
        // --- Put your Zirka v7+++ encoding logic here ---
        
    }

// [sanmayce@djudjeto v7+]$ echo -n Sanmayce> Sanmayce 
// [sanmayce@djudjeto v7+]$ sha1sum Sanmayce 
// 8ecfb9435b758ba69d424f0aa003f6e3dc5943b3  Sanmayce

/*
char Sanmayce[] = "Sanmayce";
uint8_t hash_out20[32];
        sha1_sum(Sanmayce, 8, (uint8_t *)hash_out20);
for (int i=0; i<20; i++) printf("%02x", hash_out20[i]);
printf("\n");
exit (1);
*/

// [sanmayce@djudjeto v7+]$ ./Zirka_v7 q
// Version 7+, Deduplication granularity 384
// 8ecfb9435b758ba69d424f0aa003f6e3dc5943b3

// malloc [
/*
    FILE* fin = fopen(argv[1], "rb");
    if (!fin) { perror("Input error"); return 1; }
    fseek(fin, 0, SEEK_END);
    uint64_t filesize = ftell(fin);
    fseek(fin, 0, SEEK_SET);

    uint64_t entry_count = (filesize >= CHUNK_SIZE) ? (filesize - CHUNK_SIZE + 1) : 0;

    char* filename = argv[1];
    
    printf("[Zirka 1-Pass] File: %s (%.2f GB)\n", filename, filesize / 1024.0 / 1024.0 / 1024.0);
    printf("[Zirka 1-Pass] Hashing to temporary MMAP file (this will use 24x filesize = ~%lu GB disk space)...\n", 
           (entry_count * sizeof(DiskEntry)) / 1024 / 1024 / 1024);
*/
// malloc ]
   
// 1. OPEN FILE & GET SIZE [
    int fd_in = open(argv[1], O_RDONLY);
    if (fd_in == -1) { perror("Open input failed"); return 1; }
    char* filename = argv[1];

    struct stat sb;
    if (fstat(fd_in, &sb) == -1) { perror("Stat failed"); return 1; }
    uint64_t filesize = sb.st_size;
    entry_count = (filesize >= CHUNK_SIZE) ? (filesize - CHUNK_SIZE + 1) : 0;

    printf("[Zirka 1-Pass] File: %s (%.2f GB, you need 50x = %.2f GB)\n", argv[1], filesize / 1024.0 / 1024.0 / 1024.0, 50.0*filesize / 1024.0 / 1024.0 / 1024.0);
    printf("[Zirka 1-Pass] Zero-RAM Mode: Input is memory-mapped (OS manages paging).\n");

    // 2. MMAP THE INPUT (Zero-RAM Magic)
    // PROT_READ: We only read. MAP_PRIVATE: Changes (if any) stay local.
    uint8_t* buffer = mmap(NULL, filesize, PROT_READ, MAP_PRIVATE, fd_in, 0);
    if (buffer == MAP_FAILED) { perror("mmap input failed"); return 1; }
    
    // Hint to OS: We will read this sequentially (speeds up Hashing phase)
    #ifdef __linux__
    madvise(buffer, filesize, MADV_SEQUENTIAL);
    #endif

    // We can close the file descriptor now; the map stays valid.
    close(fd_in);
// 1. OPEN FILE & GET SIZE ]

// OLD-n-SLOW [[[[[
/*
    // 1. CREATE DISK INDEX
    printf("1. Creating Index (24x Filesize using MMAP, %lu entries)...\n", entry_count);
    DiskEntry* index = create_mmap_file("zirka_index.tmp", entry_count * sizeof(DiskEntry));
        #ifdef eXdupe
    printf("   Hashing (Parallel Pippip, taking 128bits=16bytes)...\n");
        #else
    printf("   Hashing (Parallel SHA1, taking 128bits=16bytes)...\n");
        #endif
    double t_start = omp_get_wtime();
    // OMP Parallel Hashing
    #pragma omp parallel for
    for(uint64_t i=0; i<entry_count; i++) {
        uint64_t hash_out[3]; // 2 for 16 bytes, 3 for 24
        //uint8_t digest[SHA1_DIGEST_SIZE];

        //FNV1A_Pippip_128((char*)buffer + i, CHUNK_SIZE, 0, hash_out);
        #ifdef eXdupe
        //void FNV1A_Pippip_Yurii_OOO_128bit_AES_TriXZi_Mikayla_forte (const char *str, size_t wrdlen, uint32_t seed, void *output) {
        FNV1A_Pippip_Yurii_OOO_128bit_AES_TriXZi_Mikayla_forte ((const char *) ((char*)buffer + i), CHUNK_SIZE, 0, hash_out);
        #else
        sha1_sum(((char*)buffer + i), CHUNK_SIZE, (uint8_t *)hash_out);
        #endif

        index[i].h1 = hash_out[0];
        index[i].h2 = hash_out[1];
        index[i].offset = i;
    }
    double hash_time = omp_get_wtime() - t_start;
    int num_threads = omp_get_max_threads(); 
    
    // Calculate volume: CHUNK_SIZE * entry_count
    // Note: We cast to double immediately to prevent 64-bit integer overflow
    double total_hashed_bytes = (double)CHUNK_SIZE * (double)entry_count;
    double total_hashed_gb = total_hashed_bytes / (1024.0 * 1024.0 * 1024.0);
    double throughput_gbs = total_hashed_gb / hash_time;

    printf("   Hashed in %.3fs\n", hash_time);
    printf("   Total Parallel Pippip Performance: %d bytes x %lu chunks / %.3fs = %.3f GB/s (%d threads)\n", 
           CHUNK_SIZE, entry_count, hash_time, throughput_gbs, num_threads);

    // 2. PARALLEL DISK SORT
    printf("2. Sorting Disk Index (Parallel Quicksort)...\n");
    t_start = omp_get_wtime();
    SortedSoFar = 0;
    // OMP Parallel Region for Recursion
    #pragma omp parallel
    {
        #pragma omp single nowait
        {
        //g_max_threads_used = omp_get_num_threads();
        omp_quicksort(index, 0, entry_count - 1);
        }
    }
            printf ("   Sort Progress = %.1f%%\n", 100.0);
    printf("   Sorted in %.2fs\n", omp_get_wtime() - t_start);
    //printf("   Max threads executed simultaneously: %d\n", g_max_threads_used);
    printf("   Total parallel tasks generated: %d\n", g_total_tasks);

#ifdef rankmapSERIAL
    // --- STAGE 3: BUILD RANK MAP (NUCLEAR OPTION) ---
    printf("3. Building Rank Map (8x Filesize using MMAP, Nuclear Mode: Sequential I/O)...\n");
    
    // 1. Create the Rank Map (initially empty)
    uint64_t* rank = create_mmap_file("zirka_rank.tmp", filesize * sizeof(uint64_t));
    
    // OPTIMIZATION: Huge Pages for random access speed later
    #ifdef __linux__
    madvise(rank, filesize * sizeof(uint64_t), MADV_HUGEPAGE);
    #endif

    // Initialize to NULL
    #pragma omp parallel for
    for(uint64_t i = 0; i < filesize; i++) rank[i] = NULL_RANK;

    // --- NUCLEAR PHASE 1: GATHER UPDATES (Sequential Write) ---
    printf("   [Nuclear] Gathering duplicates (16x Filesize using MMAP)...\n");
    
    // Create a temporary buffer for updates. 
    // Max possible updates = entry_count (worst case).
    RankUpdate* updates = create_mmap_file("zirka_updates.tmp", entry_count * sizeof(RankUpdate));
    update_count = 0;

    #pragma omp parallel for schedule(dynamic, 4096)
    for (uint64_t i = 0; i < entry_count; i++) {
        // Skip if not the "Group Leader" (First of identical hashes)
        if (i > 0) {
            if (index[i].h2 == index[i-1].h2 && index[i].h1 == index[i-1].h1) continue;
        }

        uint64_t group_start = i;
        // Since we sorted by Hash+Offset, this is the absolute first occurrence
        uint64_t master_offset = index[group_start].offset; 

        // Scan the group to find duplicates
        uint64_t look = group_start + 1;
        uint64_t local_dupes = 0;
        
        // Count first to reserve space atomically
        uint64_t temp_look = look;
        while (temp_look < entry_count && 
               index[temp_look].h2 == index[group_start].h2 && 
               index[temp_look].h1 == index[group_start].h1) {
            local_dupes++;
            temp_look++;
        }

        if (local_dupes > 0) {
            uint64_t my_write_idx;
            #pragma omp atomic capture
            { my_write_idx = update_count; update_count += local_dupes; }

            // Write the updates: "At position [duplicate], point to [master]"
            while (look < entry_count && 
                   index[look].h2 == index[group_start].h2 && 
                   index[look].h1 == index[group_start].h1) {
                
                updates[my_write_idx].pos = index[look].offset; 
                updates[my_write_idx].target = master_offset;   
                
                my_write_idx++;
                look++;
            }
        }
    }
    printf("   [Nuclear] Found %lu duplicates to link.\n", update_count);

    // --- NUCLEAR PHASE 2: SORT UPDATES (Transforms Random I/O to Sequential) ---
    if (update_count > 0) {
        printf("   [Nuclear] Sorting updates by file position...\n");
        SortedSoFar = 0;
        #pragma omp parallel
        {
            #pragma omp single nowait
            omp_quicksort_updates(updates, 0, update_count - 1);
        }
            printf ("   Sort Progress = %.1f%%\n", 100.0);

        // --- NUCLEAR PHASE 3: APPLY UPDATES (Monotonic Write) ---
        printf("   [Nuclear] Applying updates to Rank Map...\n");
        #pragma omp parallel for schedule(static)
        for (uint64_t i = 0; i < update_count; i++) {
            rank[updates[i].pos] = updates[i].target;
        }
    }

    // Clean up temporary updates file
    munmap(updates, entry_count * sizeof(RankUpdate));
    unlink("zirka_updates.tmp"); // Uncomment to delete temp file

    // Free the Index (We don't need it anymore for Encoding!)
    munmap(index, entry_count * sizeof(DiskEntry));
    unlink("zirka_index.tmp");

    // --- STAGE 4: ENCODER (CORRECT "FIRST OCCURRENCE" LOGIC) ---
    printf("4. Encoding (Direct Rank Lookup)...\n");
    char out_name[512]; snprintf(out_name, 512, "%s.zirka", argv[1]);
    FILE* fout = fopen(out_name, "wb");
    uint64_t pos = 0;
    uint64_t prcnt = 0;
    uint32_t chk[4];
    
    while(pos < filesize) {
        // Direct Lookup: rank[pos] contains the OFFSET of the duplicate
        uint64_t match_off = rank[pos];

        if (match_off != NULL_RANK) {
            // Safety: It must be a backward reference
            if (match_off + CHUNK_SIZE <= pos) {
                // Verify content (Paranoia check)
                if (memcmp(buffer + pos, buffer + match_off, CHUNK_SIZE) == 0) {
                    fputc(MAGIC_BYTE, fout);
                    fwrite(&match_off, 8, 1, fout);
                    //uint32_t chk = calc_fnv_off(match_off);
                    FNV1A_Pippip_Yurii_OOO_128bit_AES_TriXZi_Mikayla_forte((const char *)&match_off, 8, 0, chk);

                    fwrite(&chk, 4, 1, fout);
                    pos += CHUNK_SIZE;
                    
                    // Progress Update
                    prcnt += CHUNK_SIZE;
                    if (prcnt >= 1*1024*1024) { 
                        printf("\r   Encoded: %.1f%%", (double)pos/filesize*100.0); 
                        prcnt = 0; 
                    }
                    continue;
                }
            }
        }
        
        // Literal
        fputc(buffer[pos], fout);
        pos++;
        
        // Progress Update (for literals)
        prcnt++;
        if (prcnt >= 1*1024*1024) { 
            printf("\r   Encoded: %.1f%%", (double)pos/filesize*100.0); 
            prcnt = 0; 
        }
    }

    printf("\r   Encoded: %.1f%%\n", 100.0); 
    printf("Done.\n");
    fclose(fout);
    //free(buffer);
    munmap(buffer, filesize);

    munmap(rank, filesize * sizeof(uint64_t));
    unlink("zirka_rank.tmp");
    return 0;
#endif
*/
// OLD-n-SLOW ]]]]]

// NEW-n-FAST [[[
    // 1. CREATE DISK INDEX
    printf("1. Creating Index (24x Filesize using MMAP, %lu entries)...\n", entry_count);
    DiskEntry* index = create_mmap_file("zirka_index.tmp", entry_count * sizeof(DiskEntry));
    printf("   Hashing (Parallel Pippip 'Heavy' + Byte Swap)...\n");

    double t_start = omp_get_wtime();
    // OMP Parallel Hashing
    #pragma omp parallel for
    for(uint64_t i=0; i<entry_count; i++) {
        uint64_t hash_out[2]; 
        FNV1A_Pippip_Yurii_OOO_128bit_AES_TriXZi_Mikayla_forte ((const char *)(buffer + i), CHUNK_SIZE, 0, hash_out);

        // FLIP TO BIG-ENDIAN FOR MEMCMP SORTING
        // We must swap all fields so they appear as "Big Numbers" in memory
        index[i].h2 = __builtin_bswap64(hash_out[1]);
        index[i].h1 = __builtin_bswap64(hash_out[0]);
        index[i].offset = __builtin_bswap64(i);
    }

    double hash_time = omp_get_wtime() - t_start;
    int num_threads = omp_get_max_threads(); 
    
    // Calculate volume: CHUNK_SIZE * entry_count
    // Note: We cast to double immediately to prevent 64-bit integer overflow
    double total_hashed_bytes = (double)CHUNK_SIZE * (double)entry_count;
    double total_hashed_gb = total_hashed_bytes / (1024.0 * 1024.0 * 1024.0);
    double throughput_gbs = total_hashed_gb / hash_time;

    printf("   Hashed in %.3fs\n", hash_time);
    printf("   Total Parallel Pippip Performance: %d bytes x %lu chunks / %.3fs = %.3f GB/s (%d threads)\n", 
           CHUNK_SIZE, entry_count, hash_time, throughput_gbs, num_threads);

// The v8 segment [[
/*
    // 2. PARALLEL DISK SORT
    printf("2. Sorting Disk Index (Parallel Quicksort + memcmp)...\n");
    t_start = omp_get_wtime();
    SortedSoFar = 0;
    
    #pragma omp parallel
    {
        #pragma omp single nowait
        {
            omp_quicksort(index, 0, entry_count - 1);
        }
    }
    printf ("   Sort Progress = %.1f%%\n", 100.0);
    printf("   Sorted in %.2fs\n", omp_get_wtime() - t_start);
    printf("   Total parallel tasks generated: %d\n", g_total_tasks);
*/
// The v8 segment ]]

// The v9 segment [[[
// 2. THE SUPERBOOST: IN-PLACE 256-WAY MSD RADIX PARTITION + QUICKSORT
    printf("2. Sorting Disk Index (Superboost: 256-Way Radix Partition -> Quicksort)...\n");
    t_start = omp_get_wtime();
    SortedSoFar = 0;

    // --- STEP A: THE CENSUS (Count frequencies of the MSB) ---
    uint64_t counts[256] = {0};
    printf("   -> Step A: Counting MSB Frequencies...\n");
    
    // We can do this in parallel using thread-local arrays to avoid atomic bottlenecks
    #pragma omp parallel 
    {
        uint64_t local_counts[256] = {0};
        #pragma omp for schedule(static)
        for(uint64_t i = 0; i < entry_count; i++) {
            // Extract the Most Significant Byte. 
            // Because h2 is Big-Endian, the highest mathematical byte is at the top 8 bits.
            uint8_t msb = ((uint8_t*)&index[i])[0]; // index[i].h2 >> 56;
            local_counts[msb]++;
        }
        // Merge local counts into the global array safely
        #pragma omp critical
        {
            for(int b = 0; b < 256; b++) counts[b] += local_counts[b];
        }
    }

    // --- STEP B: PREFIX SUMS (Calculate absolute starting offsets for each bucket) ---
    uint64_t offsets[256];
    uint64_t work_offsets[256]; // A moving pointer for the swap phase
    uint64_t current_pos = 0;
    
    for(int b = 0; b < 256; b++) {
        offsets[b] = current_pos;
        work_offsets[b] = current_pos;
        current_pos += counts[b];
    }

    // --- STEP C: THE SWARM (In-Place Permutation) ---
    printf("   -> Step B: In-Place Permutation (Zero Extra Disk Space)...\n");
    // This is done serially because threads swapping across 600GB will cause massive lock contention.
    // With your 1.5TB RAM, the OS Page Cache will handle these random jumps beautifully.
    for(int b = 0; b < 256; b++) {
        // While the current bucket is not fully populated with its own items
        while(work_offsets[b] < offsets[b] + counts[b]) {
            uint64_t i = work_offsets[b];
            uint8_t msb = ((uint8_t*)&index[i])[0]; // index[i].h2 >> 56;
            
            if(msb == b) {
                // It's already in the correct bucket. Move the pointer forward.
                work_offsets[b]++;
            } else {
                // It belongs in bucket 'msb'. Swap it to the next available slot in that bucket.
                uint64_t target_idx = work_offsets[msb];
                
                DiskEntry temp = index[i];
                index[i] = index[target_idx];
                index[target_idx] = temp;
                
                // Now the target bucket has one more correct item
                work_offsets[msb]++;
                
                // Note: We DO NOT increment work_offsets[b] here, because the new item swapped 
                // into index[i] still needs to be evaluated on the next loop iteration.
            }
        }
    }

    // --- STEP D: 256-WAY PARALLEL QUICKSORT ---
    printf("   -> Step C: Launching 256 Independent Parallel Quicksorts...\n");
    // We use schedule(dynamic, 1) because some buckets might be larger than others.
    // Dynamic scheduling ensures threads that finish a small bucket immediately grab the next one.
    
    #pragma omp parallel for schedule(dynamic, 1)
    for(int b = 0; b < 256; b++) {
        if(counts[b] > 0) {
            uint64_t left_bound = offsets[b];
            uint64_t right_bound = offsets[b] + counts[b] - 1;
            
            // The quicksort now only has to sort the items inside this specific bucket
            omp_quicksort(index, left_bound, right_bound);
        }
    }

    printf ("   Sort Progress = %.1f%%\n", 100.0);
    printf("   Superboost Sort Completed in %.2fs\n", omp_get_wtime() - t_start);
// The v9 segment ]]]

#ifdef rankmapSERIAL
    // --- STAGE 3: BUILD RANK MAP (NUCLEAR OPTION) ---
    printf("3. Building Rank Map (8x Filesize using MMAP, Nuclear Mode)...\n");
    
    uint64_t* rank = create_mmap_file("zirka_rank.tmp", filesize * sizeof(uint64_t));
    #ifdef __linux__
    madvise(rank, filesize * sizeof(uint64_t), MADV_HUGEPAGE);
    #endif

    #pragma omp parallel for
    for(uint64_t i = 0; i < filesize; i++) rank[i] = NULL_RANK;

    // --- NUCLEAR PHASE 1: GATHER UPDATES ---
    printf("   [Nuclear] Gathering duplicates...\n");
    RankUpdate* updates = create_mmap_file("zirka_updates.tmp", entry_count * sizeof(RankUpdate));
    update_count = 0;

    #pragma omp parallel for schedule(dynamic, 4096)
    for (uint64_t i = 0; i < entry_count; i++) {
        // NOTE: index[] entries are currently BIG-ENDIAN.
        // Equality checks (==) work fine on BE numbers.
        // Magnitude checks (<, >) work fine on BE numbers.
        // BUT extraction (reading the value) requires a swap back.

        // Skip if not the "Group Leader"
        if (i > 0) {
            if (index[i].h2 == index[i-1].h2 && index[i].h1 == index[i-1].h1) continue;
        }

        uint64_t group_start = i;
        // SWAP BACK: Convert BE offset to LE for actual usage
        uint64_t master_offset = __builtin_bswap64(index[group_start].offset); 

        uint64_t look = group_start + 1;
        uint64_t local_dupes = 0;
        
        uint64_t temp_look = look;
        while (temp_look < entry_count && 
               index[temp_look].h2 == index[group_start].h2 && 
               index[temp_look].h1 == index[group_start].h1) {
            local_dupes++;
            temp_look++;
        }

        if (local_dupes > 0) {
            uint64_t my_write_idx;
            #pragma omp atomic capture
            { my_write_idx = update_count; update_count += local_dupes; }

            while (look < entry_count && 
                   index[look].h2 == index[group_start].h2 && 
                   index[look].h1 == index[group_start].h1) {
                
                // SWAP BACK: Convert BE offset to LE for the Update List
                updates[my_write_idx].pos = __builtin_bswap64(index[look].offset); 
                updates[my_write_idx].target = master_offset;   
                
                my_write_idx++;
                look++;
            }
        }
    }
    printf("   [Nuclear] Found %lu duplicates to link.\n", update_count);

    // --- NUCLEAR PHASE 2: SORT UPDATES ---
    if (update_count > 0) {
        printf("   [Nuclear] Sorting updates by file position...\n");
        SortedSoFar = 0;
        #pragma omp parallel
        {
            #pragma omp single nowait
            omp_quicksort_updates(updates, 0, update_count - 1);
        }
        printf ("   Sort Progress = %.1f%%\n", 100.0);

        // --- NUCLEAR PHASE 3: APPLY UPDATES ---
        printf("   [Nuclear] Applying updates to Rank Map...\n");
        #pragma omp parallel for schedule(static)
        for (uint64_t i = 0; i < update_count; i++) {
            rank[updates[i].pos] = updates[i].target;
        }
    }

    munmap(updates, entry_count * sizeof(RankUpdate));
    unlink("zirka_updates.tmp"); 
    munmap(index, entry_count * sizeof(DiskEntry));
    unlink("zirka_index.tmp");

    // --- STAGE 4: ENCODER ---
    printf("4. Encoding (Direct Rank Lookup)...\n");
    char out_name[512]; snprintf(out_name, 512, "%s.zirka", argv[1]);
    FILE* fout = fopen(out_name, "wb");
    uint64_t pos = 0;
    uint64_t prcnt = 0;
    uint32_t chk[4];
    
    while(pos < filesize) {
        uint64_t match_off = rank[pos];

        if (match_off != NULL_RANK) {
            if (match_off + CHUNK_SIZE <= pos) {
                if (memcmp(buffer + pos, buffer + match_off, CHUNK_SIZE) == 0) {
                    fputc(MAGIC_BYTE, fout);
                    fwrite(&match_off, 8, 1, fout);
                    
                    // Generate checksum of the OFFSET, not content
                    // (Matching v7++ Logic)
                    FNV1A_Pippip_Yurii_OOO_128bit_AES_TriXZi_Mikayla_forte((const char *)&match_off, 8, 0, chk);
                    fwrite(&chk, 4, 1, fout);

                    pos += CHUNK_SIZE;
                    prcnt += CHUNK_SIZE;
                    if (prcnt >= 1*1024*1024) { 
                        printf("\r   Encoded: %.1f%%", (double)pos/filesize*100.0); 
                        prcnt = 0; 
                    }
                    continue;
                }
            }
        }
        
        fputc(buffer[pos], fout);
        pos++;
        prcnt++;
        if (prcnt >= 1*1024*1024) { 
            printf("\r   Encoded: %.1f%%", (double)pos/filesize*100.0); 
            prcnt = 0; 
        }
    }

    printf("\r   Encoded: %.1f%%\n", 100.0); 
    printf("Done.\n");
    fclose(fout);
    munmap(buffer, filesize);
    munmap(rank, filesize * sizeof(uint64_t));
    unlink("zirka_rank.tmp");
    return 0;
#endif
// NEW-n-FAST ]]]

}

/*
[sanmayce@djudjeto v9]$ clang -O3 -msse4.2 -maes -fopenmp FastZirka_v9.c -o FastZirka_v9 -DrankmapSERIAL
[sanmayce@djudjeto v9]$ /bin/time -v ./FastZirka_v9 SUPRAPIG_Sefaria-Export-master_\(62438-folders_82694-files\).tar 
__________.__        __            
\____    /|__|______|  | _______   
  /     / |  \_  __ \  |/ /\__  \  
 /     /_ |  ||  | \/    <  / __ \_
/_______ \|__||__|  |__|_ \(____  /
        \/               \/     \/ 
The ZER0-RAM Deduplicator, version 9, Deduplication granularity 4096
Storage Report (Caution: You need 49x+1x=50x the size of file_for_deduplication):
--------------------------------------------------------------------------------------------------------------
CURRENT DRIVE   [.                                       ] :  1832.58 GB Total |  1403.38 GB Free (23.4% Used)
--------------------------------------------------------------------------------------------------------------
   Action: ZIRKA (Compressing SUPRAPIG_Sefaria-Export-master_(62438-folders_82694-files).tar)
[Zirka 1-Pass] File: SUPRAPIG_Sefaria-Export-master_(62438-folders_82694-files).tar (25.55 GB, you need 50x = 1277.62 GB)
[Zirka 1-Pass] Zero-RAM Mode: Input is memory-mapped (OS manages paging).
1. Creating Index (24x Filesize using MMAP, 27436713473 entries)...
   Hashing (Parallel Pippip 'Heavy' + Byte Swap)...
   Hashed in 791.459s
   Total Parallel Pippip Performance: 4096 bytes x 27436713473 chunks / 791.459s = 132.240 GB/s (16 threads)
2. Sorting Disk Index (Superboost: 256-Way Radix Partition -> Quicksort)...
   -> Step A: Counting MSB Frequencies...
   -> Step B: In-Place Permutation (Zero Extra Disk Space)...
   -> Step C: Launching 256 Independent Parallel Quicksorts...
   Sort Progress = 100.0%
   Superboost Sort Completed in 6092.34s
3. Building Rank Map (8x Filesize using MMAP, Nuclear Mode)...
   [Nuclear] Gathering duplicates...
   [Nuclear] Found 13381855880 duplicates to link.
   [Nuclear] Sorting updates by file position...
   Sort Progress = 100.0%
   [Nuclear] Applying updates to Rank Map...
4. Encoding (Direct Rank Lookup)...
   Encoded: 100.0%
Done.
	Command being timed: "./FastZirka_v9 SUPRAPIG_Sefaria-Export-master_(62438-folders_82694-files).tar"
	User time (seconds): 58217.84
	System time (seconds): 11536.47
	Percent of CPU this job got: 566%
	Elapsed (wall clock) time (h:mm:ss or m:ss): 3:25:10
	Average shared text size (kbytes): 0
	Average unshared data size (kbytes): 0
	Average stack size (kbytes): 0
	Average total size (kbytes): 0
	Maximum resident set size (kbytes): 104801964
	Average resident set size (kbytes): 0
	Major (requiring I/O) page faults: 45640811
	Minor (reclaiming a frame) page faults: 1904261584
	Voluntary context switches: 339430019
	Involuntary context switches: 20511454
	Swaps: 0
	File system inputs: 9109980056
	File system outputs: 10789949032
	Socket messages sent: 0
	Socket messages received: 0
	Signals delivered: 0
	Page size (bytes): 4096
	Exit status: 0

[sanmayce@djudjeto v9]$ ls -l
-rw-r--r-- 1 sanmayce sanmayce 27436717568 Jan 28 18:27 'SUPRAPIG_Sefaria-Export-master_(62438-folders_82694-files).tar'
-rw-r--r-- 1 sanmayce sanmayce 13490639033 Feb 20 09:41 'SUPRAPIG_Sefaria-Export-master_(62438-folders_82694-files).tar.zirka'

[sanmayce@djudjeto v9]$ /bin/time -v ./FastZirka_v9 SUPRAPIG_Sefaria-Export-master_\(62438-folders_82694-files\).tar.zirka 
__________.__        __            
\____    /|__|______|  | _______   
  /     / |  \_  __ \  |/ /\__  \  
 /     /_ |  ||  | \/    <  / __ \_
/_______ \|__||__|  |__|_ \(____  /
        \/               \/     \/ 
The ZER0-RAM Deduplicator, version 9, Deduplication granularity 4096
Storage Report (Caution: You need 49x+1x=50x the size of file_for_deduplication):
--------------------------------------------------------------------------------------------------------------
CURRENT DRIVE   [.                                       ] :  1832.58 GB Total |  1390.82 GB Free (24.1% Used)
--------------------------------------------------------------------------------------------------------------
   Action: UNZIRKA (Decompressing SUPRAPIG_Sefaria-Export-master_(62438-folders_82694-files).tar.zirka)
[Zirka v9 Restorer] Processing SUPRAPIG_Sefaria-Export-master_(62438-folders_82694-files).tar.zirka...
Restoration Complete.
Dedup Tags Processed: 3415645
Final File Size: 27436717568 bytes
	Command being timed: "./FastZirka_v9 SUPRAPIG_Sefaria-Export-master_(62438-folders_82694-files).tar.zirka"
	User time (seconds): 8.63
	System time (seconds): 10.41
	Percent of CPU this job got: 55%
	Elapsed (wall clock) time (h:mm:ss or m:ss): 0:34.30
	Average shared text size (kbytes): 0
	Average unshared data size (kbytes): 0
	Average stack size (kbytes): 0
	Average total size (kbytes): 0
	Maximum resident set size (kbytes): 24261432
	Average resident set size (kbytes): 0
	Major (requiring I/O) page faults: 8
	Minor (reclaiming a frame) page faults: 7060922
	Voluntary context switches: 15540
	Involuntary context switches: 163
	Swaps: 0
	File system inputs: 25429112
	File system outputs: 53587456
	Socket messages sent: 0
	Socket messages received: 0
	Signals delivered: 0
	Page size (bytes): 4096
	Exit status: 0
[sanmayce@djudjeto v9]$ b3sum SUPRAPIG_Sefaria-Export-master_\(62438-folders_82694-files\).tar
fe1bf9b7f83bcc8b8edead02e4eef0e8f8d8ee4f1e9a8c0f14591c8c50528b40  SUPRAPIG_Sefaria-Export-master_(62438-folders_82694-files).tar
[sanmayce@djudjeto v9]$ b3sum SUPRAPIG_Sefaria-Export-master_\(62438-folders_82694-files\).tar.zirka.restored 
fe1bf9b7f83bcc8b8edead02e4eef0e8f8d8ee4f1e9a8c0f14591c8c50528b40  SUPRAPIG_Sefaria-Export-master_(62438-folders_82694-files).tar.zirka.restored
[sanmayce@djudjeto v9]$ 
*/

