// Compile: clang -O3 DiffCatch.c -o DiffCatch
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/stat.h>

int main(int argc, char* argv[]) {
    if (argc < 3) {
        printf("Usage: %s <original_file> <restored_file>\n", argv[0]);
        return 1;
    }

    int fd1 = open(argv[1], O_RDONLY);
    int fd2 = open(argv[2], O_RDONLY);

    if (fd1 < 0 || fd2 < 0) { perror("File opening failed"); return 1; }

    struct stat sb1, sb2;
    fstat(fd1, &sb1);
    fstat(fd2, &sb2);

    if (sb1.st_size != sb2.st_size) {
        printf("CRITICAL SIZE MISMATCH!\n");
        printf("File 1: %lu bytes\n", sb1.st_size);
        printf("File 2: %lu bytes\n", sb2.st_size);
        // We continue anyway to see where the data diverges
    }

    uint64_t size = (sb1.st_size < sb2.st_size) ? sb1.st_size : sb2.st_size;
    
    uint8_t* m1 = mmap(NULL, sb1.st_size, PROT_READ, MAP_PRIVATE, fd1, 0);
    uint8_t* m2 = mmap(NULL, sb2.st_size, PROT_READ, MAP_PRIVATE, fd2, 0);

    uint64_t mismatch_count = 0;
    uint64_t first_mismatch = 0xFFFFFFFFFFFFFFFF;

    printf("Comparing files byte-by-byte...\n");

    for (uint64_t i = 0; i < size; i++) {
        if (m1[i] != m2[i]) {
            if (mismatch_count == 0) first_mismatch = i;
            mismatch_count++;
            
            // Print details for the first 10 errors to see the pattern
            if (mismatch_count <= 10) {
                printf("Mismatch at 0x%lx: Orig[0x%02x] != Restored[0x%02x]\n", 
                        i, m1[i], m2[i]);
            }
        }
    }

    printf("--------------------------------------\n");
    if (mismatch_count == 0 && sb1.st_size == sb2.st_size) {
        printf("SUCCESS: Files are identical.\n");
    } else {
        printf("Found %lu bytes mismatching.\n", mismatch_count);
        if (first_mismatch != 0xFFFFFFFFFFFFFFFF) {
            printf("First error occurred at offset: %lu (0x%lx)\n", first_mismatch, first_mismatch);
            printf("Relative to CHUNK_SIZE (384): Offset %% 384 = %lu\n", first_mismatch % 384);
        }
    }

    munmap(m1, sb1.st_size);
    munmap(m2, sb2.st_size);
    close(fd1);
    close(fd2);
    return 0;
}

