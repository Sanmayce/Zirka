#!/bin/bash

# Should be as su

# Configuration
DRIVE="/dev/nvme1n1p2" # Change this to your actual device
CMD="./FastZirka_v7++_Final"        # The command to run
ARGS="$1"            # The argument passed to the script

# Function to get the raw integer value (removing commas)
# Usage: get_smart_val "Read" OR get_smart_val "Written"
get_smart_val() {
    local type="$1"
    # Run smartctl, filter for the line, extract the number, remove commas
    sudo smartctl -a "$DRIVE" | grep "Data Units $type" | awk '{print $4}' | tr -d ','
}

echo "-----------------------------------------------------------"
echo " [Snapshot 1] Reading SMART counters from $DRIVE..."
START_READ=$(get_smart_val "Read")
START_WRITE=$(get_smart_val "Written")

echo "   Start Read  : $START_READ units"
echo "   Start Write : $START_WRITE units"
echo "-----------------------------------------------------------"
echo 

# --- RUN THE PAYLOAD ---
echo " [Running] $CMD $ARGS"
start_time=$(date +%s)

/bin/time -v $CMD "$ARGS"

end_time=$(date +%s)
duration=$((end_time - start_time))
#echo " [Finished] Execution took $duration seconds."

# --- SNAPSHOT 2 ---
echo 
echo "-----------------------------------------------------------"
echo " [Snapshot 2] Reading SMART counters..."
END_READ=$(get_smart_val "Read")
END_WRITE=$(get_smart_val "Written")

echo "   End Read    : $END_READ units"
echo "   End Write   : $END_WRITE units"
echo "-----------------------------------------------------------"

# --- CALCULATIONS ---
# Bash arithmetic to find the delta
DIFF_READ=$((END_READ - START_READ))
DIFF_WRITE=$((END_WRITE - START_WRITE))

# NVMe Data Units are typically 1000 blocks of 512 bytes = 512,000 bytes
UNIT_SIZE=512000

# Convert to Bytes
BYTES_READ=$((DIFF_READ * UNIT_SIZE))
BYTES_WRITE=$((DIFF_WRITE * UNIT_SIZE))

# Convert to GB (using 1024^3 = 1,073,741,824) for readability
# We use awk for floating point division since bash doesn't support it natively
GB_READ=$(awk "BEGIN {printf \"%.2f\", $BYTES_READ/1073741824}")
GB_WRITE=$(awk "BEGIN {printf \"%.2f\", $BYTES_WRITE/1073741824}")

echo 
echo "====================================================="
echo " DATA USAGE REPORT"
echo "====================================================="
echo " Data Read    : $DIFF_READ units (~$GB_READ GB)"
echo " Data Written : $DIFF_WRITE units (~$GB_WRITE GB)"
echo "====================================================="
